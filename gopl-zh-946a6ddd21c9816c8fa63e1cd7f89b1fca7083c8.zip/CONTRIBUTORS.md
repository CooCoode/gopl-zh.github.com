# 贡献者

译者                                   | 章节
-------------------------------------- | -------------------------
`chai2010     <chaishushan@gmail.com>` | 前言/第2~4章/第10~13章
`Xargin       <cao1988228@163.com>`    | 第1章/第6章/第8~9章
`CrazySssst`                           | 第5章
`foreversmart <njutree@gmail.com>`     | 第7章

# 译文授权

除特别注明外, 本站内容均采用[知识共享-署名(CC-BY) 3.0协议](http://creativecommons.org/licenses/by/3.0/)授权, 代码遵循[Go项目的BSD协议](http://golang.org/LICENSE)授权.

<a rel="license" href="http://creativecommons.org/licenses/by-nc-sa/4.0/"><img alt="Creative Commons License" style="border-width:0" src="./images/by-nc-sa-4.0-88x31.png"></img></a>
